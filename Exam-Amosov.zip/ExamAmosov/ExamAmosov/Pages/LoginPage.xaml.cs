﻿using ExamAmosov.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamAmosov.Models.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            String login = TBLogin.Text;
            String Password = TBPassword.Text;
            String KodovoeSlovo = TBKodovoeSlovo.Text;

            var loggedMeneger = App.DB.Meneger.FirstOrDefault(X => X.login == login && X.Password == Password && X.Password == Password);
            if (loggedMeneger == null)
            {
                MessageBox.Show("Не верный логин либо пароль");
                return;
            }
            App.loggedMeneger = loggedMeneger;
            if (loggedMeneger.IdMeneger ==1)
            {
                NavigationService.Navigate(new MenegerPage());
                MessageBox.Show("Добро пожаловать");
            }
        }
    }
}
